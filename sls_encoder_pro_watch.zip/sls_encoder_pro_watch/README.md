Please see the notes at the top of the .ino file.
Extract downloaded zip file and rename the folder "sls_encoder_pro_watch"
